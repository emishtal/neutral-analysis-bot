# ⚡ БЫСТРЫЙ СТАРТ (ШПАРГАЛКА)

Если ты уже всё настраивал и просто хочешь запустить проект снова.

## Запуск проекта

```bash
# 1. Перейди в папку проекта
cd trust-profile

# 2. Запусти
npm run dev

# 3. Открой браузер
# http://localhost:3000
```

## Остановка проекта

В терминале нажми: **`Ctrl + C`**

## Если забыл пароли/ключи

### Supabase ключи:
1. Открой https://supabase.com
2. Войди в свой проект
3. Settings → API
4. Скопируй нужные ключи

### Resend ключ:
1. Открой https://resend.com
2. API Keys
3. Создай новый (старые не показываются)

## Структура проекта

```
trust-profile/
├── app/
│   ├── page.tsx              ← Главная страница
│   ├── auth/
│   │   ├── signup/page.tsx   ← Регистрация
│   │   ├── signin/page.tsx   ← Вход
│   │   └── error/page.tsx    ← Ошибки
│   ├── verify-email/page.tsx ← Подтверждение email
│   └── api/
│       └── auth/
│           ├── signup/route.ts      ← API регистрации
│           └── verify-email/route.ts ← API верификации
├── lib/
│   ├── supabase.ts    ← Подключение к БД
│   ├── email.ts       ← Отправка писем
│   └── utils.ts       ← Вспомогательные функции
├── .env.local         ← ⚠️ СЕКРЕТНЫЕ КЛЮЧИ
└── supabase-schema.sql ← Схема БД
```

## Полезные команды

```bash
# Установить зависимости
npm install

# Запустить в dev режиме
npm run dev

# Собрать для production
npm run build

# Запустить production версию
npm start

# Очистить node_modules и переустановить
rm -rf node_modules
npm install
```

## Базовые URL

- **Локальный сайт:** http://localhost:3000
- **Регистрация:** http://localhost:3000/auth/signup
- **Вход:** http://localhost:3000/auth/signin
- **Dashboard:** http://localhost:3000/dashboard (скоро)

## Если что-то сломалось

```bash
# 1. Остановить проект
Ctrl + C

# 2. Очистить кеш
rm -rf .next

# 3. Переустановить зависимости
rm -rf node_modules
npm install

# 4. Запустить снова
npm run dev
```

## Проверка что всё работает

1. ✅ Проект запускается без ошибок
2. ✅ Главная страница открывается
3. ✅ Регистрация работает
4. ✅ Письмо приходит на почту
5. ✅ Email подтверждается
6. ✅ Вход работает

---

**Для подробной инструкции смотри:** `SETUP-GUIDE.md`
