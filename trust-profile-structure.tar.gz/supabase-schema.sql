-- Trust Profile Database Schema
-- PostgreSQL / Supabase

-- ====================================
-- 1. USERS TABLE
-- ====================================
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  name VARCHAR(255) NOT NULL,
  profile_slug VARCHAR(255) UNIQUE NOT NULL,
  email_verified BOOLEAN DEFAULT FALSE,
  phone VARCHAR(50),
  phone_verified BOOLEAN DEFAULT FALSE,
  trust_level VARCHAR(20) DEFAULT 'new' CHECK (trust_level IN ('new', 'basic', 'verified')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index для быстрого поиска по email
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_profile_slug ON users(profile_slug);

-- ====================================
-- 2. EMAIL VERIFICATION TOKENS
-- ====================================
CREATE TABLE IF NOT EXISTS email_verification_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  token UUID DEFAULT gen_random_uuid() UNIQUE NOT NULL,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  used_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_email_tokens_token ON email_verification_tokens(token);
CREATE INDEX IF NOT EXISTS idx_email_tokens_user ON email_verification_tokens(user_id);

-- ====================================
-- 3. TRUST EVENTS (Ядро системы)
-- ====================================
CREATE TABLE IF NOT EXISTS trust_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id UUID REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  
  -- Детали работы
  service_type VARCHAR(255) NOT NULL,
  description TEXT NOT NULL CHECK (length(description) <= 500),
  
  -- Сроки
  claimed_duration INTEGER, -- days
  actual_duration INTEGER, -- days, если была корректировка
  
  -- Сумма
  claimed_amount DECIMAL(10, 2),
  actual_amount DECIMAL(10, 2),
  currency VARCHAR(3) DEFAULT 'EUR',
  
  -- Контрагент
  counterparty_email VARCHAR(255),
  counterparty_name VARCHAR(255), -- если заказчик укажет при подтверждении
  counterparty_anonymous BOOLEAN DEFAULT FALSE,
  
  -- Статусы
  status VARCHAR(30) DEFAULT 'pending' CHECK (
    status IN ('pending', 'confirmed', 'confirmed_with_edits', 'disputed', 'expired')
  ),
  
  -- Метаданные
  ip_hash VARCHAR(64),
  user_agent_hash VARCHAR(64),
  
  -- Timestamps
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  confirmed_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_events_creator ON trust_events(creator_id);
CREATE INDEX IF NOT EXISTS idx_events_status ON trust_events(status);
CREATE INDEX IF NOT EXISTS idx_events_created ON trust_events(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_events_counterparty_email ON trust_events(counterparty_email);

-- ====================================
-- 4. CONFIRMATION LINKS
-- ====================================
CREATE TABLE IF NOT EXISTS confirmation_links (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id UUID REFERENCES trust_events(id) ON DELETE CASCADE NOT NULL,
  token UUID DEFAULT gen_random_uuid() UNIQUE NOT NULL,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  used_at TIMESTAMP WITH TIME ZONE,
  confirmation_receipt_token UUID DEFAULT gen_random_uuid() UNIQUE, -- для квитанции заказчика
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_confirmation_token ON confirmation_links(token);
CREATE INDEX IF NOT EXISTS idx_confirmation_event ON confirmation_links(event_id);
CREATE INDEX IF NOT EXISTS idx_confirmation_receipt ON confirmation_links(confirmation_receipt_token);

-- ====================================
-- 5. DISPUTES (Споры)
-- ====================================
CREATE TABLE IF NOT EXISTS disputes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id UUID REFERENCES trust_events(id) ON DELETE CASCADE NOT NULL,
  reason VARCHAR(100) NOT NULL,
  comment TEXT CHECK (length(comment) <= 1000),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_disputes_event ON disputes(event_id);

-- ====================================
-- 6. TRIGGERS
-- ====================================

-- Auto-update updated_at для users
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_events_updated_at BEFORE UPDATE ON trust_events
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ====================================
-- 7. ФУНКЦИЯ: Автоматический расчёт Trust Level
-- ====================================
CREATE OR REPLACE FUNCTION calculate_trust_level(user_uuid UUID)
RETURNS VARCHAR(20) AS $$
DECLARE
  confirmed_count INTEGER;
  unique_counterparties INTEGER;
  account_age_days INTEGER;
  active_disputes INTEGER;
BEGIN
  -- Подсчёт подтверждённых событий
  SELECT COUNT(*) INTO confirmed_count
  FROM trust_events
  WHERE creator_id = user_uuid 
    AND status IN ('confirmed', 'confirmed_with_edits');
  
  -- Подсчёт уникальных заказчиков
  SELECT COUNT(DISTINCT counterparty_email) INTO unique_counterparties
  FROM trust_events
  WHERE creator_id = user_uuid
    AND status IN ('confirmed', 'confirmed_with_edits')
    AND counterparty_email IS NOT NULL;
  
  -- Возраст аккаунта (в днях)
  SELECT EXTRACT(DAY FROM NOW() - created_at) INTO account_age_days
  FROM users
  WHERE id = user_uuid;
  
  -- Активные споры
  SELECT COUNT(*) INTO active_disputes
  FROM disputes d
  JOIN trust_events e ON d.event_id = e.id
  WHERE e.creator_id = user_uuid;
  
  -- Логика определения уровня
  IF confirmed_count >= 5 
     AND unique_counterparties >= 3 
     AND account_age_days >= 30 
     AND active_disputes = 0 THEN
    RETURN 'verified';
  ELSIF confirmed_count >= 1 THEN
    RETURN 'basic';
  ELSE
    RETURN 'new';
  END IF;
END;
$$ LANGUAGE plpgsql;

-- ====================================
-- 8. ТРИГГЕР: Обновление Trust Level при изменении событий
-- ====================================
CREATE OR REPLACE FUNCTION update_user_trust_level()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE users
  SET trust_level = calculate_trust_level(NEW.creator_id)
  WHERE id = NEW.creator_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_trust_level 
AFTER INSERT OR UPDATE ON trust_events
FOR EACH ROW EXECUTE FUNCTION update_user_trust_level();

-- ====================================
-- 9. RLS (Row Level Security) - опционально
-- ====================================
-- Можно включить позже для дополнительной безопасности

-- ALTER TABLE users ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE trust_events ENABLE ROW LEVEL SECURITY;

-- CREATE POLICY "Users can view their own data" ON users
--   FOR SELECT USING (auth.uid() = id);

-- ====================================
-- 10. НАЧАЛЬНЫЕ ДАННЫЕ (для тестирования)
-- ====================================

-- Список типов услуг (можно расширять)
-- Будет использоваться в dropdown на фронте

-- Таблица service_types (опционально, для нормализации)
CREATE TABLE IF NOT EXISTS service_types (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) UNIQUE NOT NULL,
  category VARCHAR(100),
  sort_order INTEGER DEFAULT 0
);

-- Начальный набор типов услуг для веб-дизайнеров/разработчиков
INSERT INTO service_types (name, category, sort_order) VALUES
  ('Дизайн лендинга', 'design', 1),
  ('Дизайн многостраничного сайта', 'design', 2),
  ('Дизайн мобильного приложения', 'design', 3),
  ('Веб-разработка (frontend)', 'development', 4),
  ('Веб-разработка (fullstack)', 'development', 5),
  ('Интеграция с API', 'development', 6),
  ('Доработка/фикс багов', 'development', 7),
  ('SEO оптимизация', 'marketing', 8),
  ('Консультация', 'consulting', 9),
  ('Другое', 'other', 999)
ON CONFLICT (name) DO NOTHING;

-- ====================================
-- ГОТОВО! Схема создана.
-- ====================================

-- Проверка созданных таблиц:
-- SELECT table_name FROM information_schema.tables WHERE table_schema = 'public';
