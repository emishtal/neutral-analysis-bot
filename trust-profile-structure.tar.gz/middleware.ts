export { auth as middleware } from "@/auth";

export const config = {
  matcher: [
    '/dashboard/:path*',
    '/profile/edit/:path*',
    '/api/events/:path*'
  ]
};
