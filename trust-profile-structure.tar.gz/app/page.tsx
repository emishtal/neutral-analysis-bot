import Link from 'next/link';
import { auth } from '@/auth';

export default async function HomePage() {
  const session = await auth();

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold mb-6 text-gray-900">
            Профиль Доверия
          </h1>
          <p className="text-xl text-gray-700 mb-4">
            Инфраструктура фиксации фактов выполненных работ
          </p>
          <p className="text-gray-600">
            Не отзывы. Не оценки. Факты.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          {session ? (
            <div className="bg-white rounded-lg shadow-sm p-8 text-center">
              <p className="text-gray-700 mb-6">
                Привет, {session.user?.name}!
              </p>
              <div className="flex gap-4 justify-center">
                <Link
                  href="/dashboard"
                  className="px-8 py-4 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors font-medium"
                >
                  Перейти в Dashboard
                </Link>
              </div>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 gap-6">
              <Link
                href="/auth/signin"
                className="bg-white rounded-lg shadow-sm p-8 text-center hover:shadow-md transition-shadow"
              >
                <div className="text-4xl mb-4">🔐</div>
                <h3 className="text-xl font-bold mb-2 text-gray-900">Войти</h3>
                <p className="text-gray-600">У меня уже есть аккаунт</p>
              </Link>

              <Link
                href="/auth/signup"
                className="bg-white rounded-lg shadow-sm p-8 text-center hover:shadow-md transition-shadow"
              >
                <div className="text-4xl mb-4">✨</div>
                <h3 className="text-xl font-bold mb-2 text-gray-900">Регистрация</h3>
                <p className="text-gray-600">Создать новый профиль</p>
              </Link>
            </div>
          )}
        </div>

        <div className="mt-20 max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-900">
            Как это работает?
          </h2>
          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-5xl mb-4">📝</div>
              <h3 className="text-xl font-bold mb-2 text-gray-900">1. Зафиксируй факт</h3>
              <p className="text-gray-600">
                Выполненная работа + подтверждение заказчика
              </p>
            </div>

            <div className="text-center">
              <div className="text-5xl mb-4">✅</div>
              <h3 className="text-xl font-bold mb-2 text-gray-900">2. Факт подтверждён</h3>
              <p className="text-gray-600">
                Заказчик подтверждает одним кликом
              </p>
            </div>

            <div className="text-center">
              <div className="text-5xl mb-4">🌟</div>
              <h3 className="text-xl font-bold mb-2 text-gray-900">3. История растёт</h3>
              <p className="text-gray-600">
                Факты навсегда в твоём профиле
              </p>
            </div>

            <div className="text-center">
              <div className="text-5xl mb-4">💎</div>
              <h3 className="text-xl font-bold mb-2 text-gray-900">Всегда бесплатно</h3>
              <p className="text-gray-600">
                Фиксация фактов — твоё право, без платных подписок
              </p>
            </div>
          </div>
        </div>

        <div className="mt-16 text-center">
          <div className="bg-gray-100 rounded-lg p-8 max-w-2xl mx-auto">
            <p className="text-sm text-gray-700 leading-relaxed">
              <strong className="text-gray-900">Профиль Доверия</strong> — это не рейтинг и не отзывы. 
              Это инфраструктура для фиксации подтверждённых фактов выполненных работ. 
              Независимо от платформ. Без субъективных оценок. Только факты.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
