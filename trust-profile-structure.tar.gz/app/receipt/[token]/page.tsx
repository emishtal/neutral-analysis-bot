import { notFound } from 'next/navigation';
import { createAdminClient } from '@/lib/supabase';
import { formatDate, formatAmount } from '@/lib/utils';

async function getReceipt(token: string) {
  try {
    const supabase = createAdminClient();

    const { data: link } = await supabase
      .from('confirmation_links')
      .select(`
        *,
        trust_events (
          *,
          users (
            name,
            profile_slug
          )
        )
      `)
      .eq('confirmation_receipt_token', token)
      .single();

    if (!link) return null;

    return {
      event: (link as any).trust_events,
      user: (link as any).trust_events.users,
      confirmed_at: link.used_at,
    };
  } catch (error) {
    return null;
  }
}

export default async function ReceiptPage({
  params,
}: {
  params: { token: string };
}) {
  const receipt = await getReceipt(params.token);

  if (!receipt) {
    notFound();
  }

  const { event, user } = receipt;

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-lg shadow-sm p-8">
          <div className="text-center mb-8">
            <div className="text-5xl mb-4">✅</div>
            <h1 className="text-3xl font-bold mb-2">Квитанция подтверждения</h1>
            <p className="text-gray-600">
              Факт выполнения работы зафиксирован
            </p>
          </div>

          <div className="border-t border-b border-gray-200 py-6 mb-6">
            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="text-gray-600">Исполнитель:</span>
                <span className="font-medium">{user.name}</span>
              </div>

              <div className="flex justify-between">
                <span className="text-gray-600">Услуга:</span>
                <span className="font-medium">{event.service_type}</span>
              </div>

              <div>
                <span className="text-gray-600 block mb-1">Описание:</span>
                <p className="text-gray-800">{event.description}</p>
              </div>

              {event.actual_duration && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Срок выполнения:</span>
                  <span className="font-medium">{event.actual_duration} дней</span>
                </div>
              )}

              {event.actual_amount && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Сумма:</span>
                  <span className="font-medium">
                    {formatAmount(event.actual_amount, event.currency)}
                  </span>
                </div>
              )}

              <div className="flex justify-between">
                <span className="text-gray-600">Создано:</span>
                <span className="font-medium">{formatDate(event.created_at)}</span>
              </div>

              <div className="flex justify-between">
                <span className="text-gray-600">Подтверждено:</span>
                <span className="font-medium">
                  {formatDate(receipt.confirmed_at || event.confirmed_at)}
                </span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-gray-600">Статус:</span>
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-50 border border-green-200 text-green-800">
                  ✅ Подтверждено
                </span>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 rounded-lg p-6 mb-6">
            <p className="text-sm text-gray-700 mb-2">
              <strong>Что подтверждает эта квитанция?</strong>
            </p>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Факт выполнения работы зафиксирован обеими сторонами</li>
              <li>• Эта ссылка может использоваться как подтверждение сделки</li>
              <li>• Информация хранится в Trust Profile</li>
            </ul>
          </div>

          <div className="text-center space-y-4">
            
              href={`/profile/${user.profile_slug}`}
              className="inline-block px-6 py-3 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors font-medium"
            >
              Посмотреть профиль исполнителя
            </a>

            <p className="text-xs text-gray-500">
              Trust Profile — инфраструктура фиксации фактов
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
