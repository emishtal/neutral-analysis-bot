'use client';

import { useState, useEffect } from 'react';
import { useSession, signOut } from 'next-auth/react';
import { redirect } from 'next/navigation';
import CreateEventForm from '@/components/CreateEventForm';
import EventsList from '@/components/EventsList';
import type { TrustEvent, DashboardStats, CreateEventResponse } from '@/types/database';
import { TRUST_LEVEL_LABELS } from '@/types/database';

export default function DashboardPage() {
  const { data: session, status } = useSession();
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [events, setEvents] = useState<TrustEvent[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  if (status === 'unauthenticated') {
    redirect('/auth/signin');
  }

  useEffect(() => {
    if (status === 'authenticated') {
      loadEvents();
    }
  }, [status]);

  const loadEvents = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/events');
      const result = await response.json();

      if (result.success) {
        setEvents(result.data);
        calculateStats(result.data);
      }
    } catch (error) {
      console.error('Failed to load events:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const calculateStats = (eventsList: TrustEvent[]) => {
    const confirmed = eventsList.filter(
      (e) => e.status === 'confirmed' || e.status === 'confirmed_with_edits'
    ).length;
    const pending = eventsList.filter((e) => e.status === 'pending').length;
    const disputed = eventsList.filter((e) => e.status === 'disputed').length;

    const uniqueEmails = new Set(
      eventsList
        .filter(
          (e) =>
            (e.status === 'confirmed' || e.status === 'confirmed_with_edits') &&
            e.counterparty_email
        )
        .map((e) => e.counterparty_email)
    );

    setStats({
      total_events: eventsList.length,
      confirmed_events: confirmed,
      pending_events: pending,
      disputed_events: disputed,
      unique_counterparties: uniqueEmails.size,
      trust_level: (session?.user as any)?.trustLevel || 'new',
    });
  };

  const handleEventCreated = (event: CreateEventResponse) => {
    setShowCreateForm(false);
    loadEvents();
  };

  if (status === 'loading' || isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    );
  }

  const trustLevelInfo = TRUST_LEVEL_LABELS[stats?.trust_level || 'new'];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Профиль Доверия</h1>
              <p className="text-gray-700 mt-1">
                {session?.user?.name} • {session?.user?.email}
              </p>
            </div>
            <div className="flex items-center gap-4">
              <a
                href={`/profile/${(session?.user as any)?.profileSlug || ''}`}
                className="px-4 py-2 text-gray-900 hover:text-gray-700 font-medium"
              >
                Мой профиль
              </a>
              <button
                onClick={() => signOut({ callbackUrl: '/auth/signin' })}
                className="px-4 py-2 text-gray-900 hover:text-gray-700 font-medium"
              >
                Выйти
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {stats && (
          <div className="mb-8">
            <div
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg ${
                trustLevelInfo.color === 'green'
                  ? 'bg-green-50 border border-green-200'
                  : trustLevelInfo.color === 'yellow'
                  ? 'bg-yellow-50 border border-yellow-200'
                  : 'bg-gray-50 border border-gray-200'
              }`}
            >
              <span className="text-2xl">{trustLevelInfo.icon}</span>
              <div>
                <div className="font-bold text-gray-900">{trustLevelInfo.label}</div>
                <div className="text-xs text-gray-700">{trustLevelInfo.description}</div>
              </div>
            </div>
          </div>
        )}

        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <StatCard
              title="Всего событий"
              value={stats.total_events}
              icon="📊"
              color="blue"
            />
            <StatCard
              title="Подтверждено"
              value={stats.confirmed_events}
              icon="✅"
              color="green"
            />
            <StatCard
              title="Ожидает"
              value={stats.pending_events}
              icon="⏳"
              color="yellow"
            />
            <StatCard
              title="Уникальных клиентов"
              value={stats.unique_counterparties}
              icon="👥"
              color="purple"
            />
          </div>
        )}

        {!showCreateForm && (
          <div className="mb-8">
            <button
              onClick={() => setShowCreateForm(true)}
              className="w-full md:w-auto px-6 py-4 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors font-medium text-lg"
            >
              ➕ Зафиксировать выполненную работу
            </button>
          </div>
        )}

        {showCreateForm && (
          <div className="mb-8">
            <CreateEventForm
              onSuccess={handleEventCreated}
              onCancel={() => setShowCreateForm(false)}
            />
          </div>
        )}

        <div>
          <h2 className="text-2xl font-bold mb-6 text-gray-900">Мои события</h2>
          <EventsList events={events} isLoading={isLoading} />
        </div>
      </div>
    </div>
  );
}

interface StatCardProps {
  title: string;
  value: number;
  icon: string;
  color: 'blue' | 'green' | 'yellow' | 'purple';
}

function StatCard({ title, value, icon, color }: StatCardProps) {
  const colorClasses = {
    blue: 'bg-blue-50 border-blue-200',
    green: 'bg-green-50 border-green-200',
    yellow: 'bg-yellow-50 border-yellow-200',
    purple: 'bg-purple-50 border-purple-200',
  };

  return (
    <div className={`bg-white rounded-lg shadow-sm border ${colorClasses[color]} p-6`}>
      <div className="flex items-center justify-between mb-2">
        <span className="text-3xl">{icon}</span>
        <span className="text-3xl font-bold text-gray-900">{value}</span>
      </div>
      <p className="text-sm text-gray-700 font-medium">{title}</p>
    </div>
  );
}
