'use client';

import { useSearchParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function VerifyEmailPage() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const [status, setStatus] = useState<'pending' | 'success' | 'error'>('pending');
  const [message, setMessage] = useState('');
  
  const email = searchParams.get('email');
  const token = searchParams.get('token');

  useEffect(() => {
    // Если есть токен, автоматически верифицируем
    if (token) {
      verifyToken(token);
    }
  }, [token]);

  const verifyToken = async (verificationToken: string) => {
    try {
      const res = await fetch('/api/auth/verify-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: verificationToken }),
      });

      const data = await res.json();

      if (res.ok) {
        setStatus('success');
        setMessage('Email успешно подтверждён!');
        
        // Редирект через 2 секунды
        setTimeout(() => {
          router.push('/auth/signin');
        }, 2000);
      } else {
        setStatus('error');
        setMessage(data.error || 'Ошибка верификации');
      }
    } catch (err) {
      setStatus('error');
      setMessage('Произошла ошибка при верификации');
    }
  };

  // Если есть токен, показываем статус верификации
  if (token) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md text-center space-y-6">
          {status === 'pending' && (
            <>
              <div className="text-6xl">⏳</div>
              <div>
                <h1 className="text-3xl font-bold tracking-tight">
                  Проверка...
                </h1>
                <p className="mt-2 text-gray-600">
                  Верифицируем ваш email
                </p>
              </div>
            </>
          )}

          {status === 'success' && (
            <>
              <div className="text-6xl">✅</div>
              <div>
                <h1 className="text-3xl font-bold tracking-tight">
                  Готово!
                </h1>
                <p className="mt-2 text-gray-600">
                  {message}
                </p>
                <p className="mt-2 text-sm text-gray-500">
                  Перенаправляем на страницу входа...
                </p>
              </div>
            </>
          )}

          {status === 'error' && (
            <>
              <div className="text-6xl">❌</div>
              <div>
                <h1 className="text-3xl font-bold tracking-tight">
                  Ошибка
                </h1>
                <p className="mt-2 text-gray-600">
                  {message}
                </p>
              </div>
              <Link
                href="/auth/signup"
                className="inline-block px-6 py-3 bg-black text-white rounded-lg font-medium hover:bg-gray-800 transition-colors"
              >
                Попробовать снова
              </Link>
            </>
          )}
        </div>
      </div>
    );
  }

  // Если нет токена, показываем инструкцию
  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md text-center space-y-6">
        <div className="text-6xl">📧</div>
        
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            Проверьте email
          </h1>
          <p className="mt-2 text-gray-600">
            Мы отправили письмо с подтверждением на:
          </p>
          {email && (
            <p className="mt-1 font-medium text-lg">
              {email}
            </p>
          )}
        </div>

        <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 text-left space-y-3">
          <p className="text-sm text-gray-700">
            <strong>Следующие шаги:</strong>
          </p>
          <ol className="text-sm text-gray-700 space-y-2 list-decimal list-inside">
            <li>Откройте письмо от Trust Profile</li>
            <li>Нажмите на ссылку подтверждения</li>
            <li>Войдите в свой аккаунт</li>
          </ol>
        </div>

        <p className="text-sm text-gray-500">
          Не получили письмо? Проверьте папку "Спам"
        </p>

        <Link
          href="/"
          className="text-sm text-gray-600 hover:text-black"
        >
          Вернуться на главную
        </Link>
      </div>
    </div>
  );
}
