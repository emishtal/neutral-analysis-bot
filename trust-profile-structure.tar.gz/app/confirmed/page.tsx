'use client';

import { Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { useState } from 'react';

function ConfirmedContent() {
  const searchParams = useSearchParams();
  const receiptToken = searchParams.get('token');
  const [copied, setCopied] = useState(false);

  const receiptUrl = receiptToken 
    ? (typeof window !== 'undefined' ? `${window.location.origin}/receipt/${receiptToken}` : '')
    : '';

  const copyToClipboard = async () => {
    if (receiptUrl) {
      await navigator.clipboard.writeText(receiptUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4 py-12">
      <div className="max-w-2xl w-full">
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <div className="text-6xl mb-6">✅</div>
          
          <h1 className="text-3xl font-bold mb-4 text-gray-900">
            Факт зафиксирован
          </h1>
          
          <p className="text-gray-700 mb-8">
            Твоё подтверждение сохранено. Спасибо!
          </p>

          {receiptUrl && (
            <div className="bg-gray-50 rounded-lg p-6 mb-8">
              <p className="text-sm text-gray-900 mb-4 font-medium">
                Сохрани эту ссылку для себя:
              </p>
              
              <div className="flex gap-2 mb-3">
                <input
                  type="text"
                  value={receiptUrl}
                  readOnly
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg bg-white text-sm text-gray-900"
                />
                <button
                  onClick={copyToClipboard}
                  className="px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors text-sm font-medium whitespace-nowrap"
                >
                  {copied ? '✓ Скопировано' : 'Копировать'}
                </button>
              </div>
              
              <p className="text-xs text-gray-600">
                Эта ссылка подтверждает, что ты работал с исполнителем и может использоваться в будущем как доказательство сделки.
              </p>
            </div>
          )}

          <div className="border-t border-gray-200 pt-6">
            <p className="text-sm text-gray-900 mb-4 font-medium">
              Что происходит дальше?
            </p>
            <ul className="text-sm text-gray-700 text-left space-y-2 max-w-md mx-auto">
              <li>• Исполнитель получит уведомление о подтверждении</li>
              <li>• Факт отобразится в его профиле доверия</li>
              <li>• Мы отправили тебе email с квитанцией</li>
            </ul>
          </div>

          <div className="mt-8">
            <a
              href="/"
              className="inline-block px-6 py-3 bg-gray-100 text-gray-900 rounded-lg hover:bg-gray-200 transition-colors font-medium"
            >
              Закрыть
            </a>
          </div>
        </div>

        <div className="mt-6 text-center">
          <p className="text-xs text-gray-500">
            Профиль Доверия — инфраструктура фиксации фактов
          </p>
        </div>
      </div>
    </div>
  );
}

export default function ConfirmedPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black"></div>
      </div>
    }>
      <ConfirmedContent />
    </Suspense>
  );
}
