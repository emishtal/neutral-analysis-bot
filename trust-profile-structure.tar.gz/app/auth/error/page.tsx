'use client';

import { useSearchParams } from 'next/navigation';
import Link from 'next/link';

const errorMessages: Record<string, string> = {
  Configuration: 'Ошибка конфигурации сервера',
  AccessDenied: 'Доступ запрещён',
  Verification: 'Токен верификации истёк или недействителен',
  Default: 'Произошла ошибка аутентификации',
};

export default function AuthErrorPage() {
  const searchParams = useSearchParams();
  const error = searchParams.get('error') || 'Default';
  const message = errorMessages[error] || errorMessages.Default;

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md text-center space-y-6">
        <div className="text-6xl">⚠️</div>
        
        <div>
          <h1 className="text-3xl font-bold tracking-tight">
            Ошибка
          </h1>
          <p className="mt-2 text-gray-600">
            {message}
          </p>
        </div>

        <div className="flex flex-col gap-3">
          <Link
            href="/auth/signin"
            className="inline-block px-6 py-3 bg-black text-white rounded-lg font-medium hover:bg-gray-800 transition-colors"
          >
            Попробовать снова
          </Link>
          
          <Link
            href="/"
            className="text-sm text-gray-600 hover:text-black"
          >
            Вернуться на главную
          </Link>
        </div>
      </div>
    </div>
  );
}
