import { notFound } from 'next/navigation';
import ConfirmEventForm from '@/components/ConfirmEventForm';

async function getEventDetails(token: string) {
  try {
    const response = await fetch(
      `${process.env.NEXT_PUBLIC_APP_URL}/api/confirm/${token}`,
      { cache: 'no-store' }
    );
    
    if (!response.ok) {
      return null;
    }
    
    const result = await response.json();
    return result.data;
  } catch (error) {
    console.error('Error fetching event:', error);
    return null;
  }
}

export default async function ConfirmPage({
  params,
}: {
  params: { token: string };
}) {
  const eventData = await getEventDetails(params.token);

  if (!eventData) {
    notFound();
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">
            Подтверждение выполнения работы
          </h1>
          <p className="text-gray-600">
            Это не отзыв и не оценка. Это просто фиксация факта.
          </p>
        </div>

        <ConfirmEventForm eventData={eventData} token={params.token} />
      </div>
    </div>
  );
}
