import { notFound } from 'next/navigation';
import { createAdminClient } from '@/lib/supabase';
import { formatDate, formatAmount } from '@/lib/utils';
import { TRUST_LEVEL_LABELS, EVENT_STATUS_LABELS } from '@/types/database';
import type { TrustEvent } from '@/types/database';

async function getProfileData(slug: string) {
  try {
    const supabase = createAdminClient();

    const { data: user } = await supabase
      .from('users')
      .select('id, name, email, trust_level, created_at, profile_slug')
      .eq('profile_slug', slug)
      .single();

    if (!user) return null;

    const { data: events } = await supabase
      .from('trust_events')
      .select('*')
      .eq('creator_id', user.id)
      .in('status', ['confirmed', 'confirmed_with_edits'])
      .order('confirmed_at', { ascending: false });

    const confirmedEvents = events || [];
    const uniqueClients = new Set(
      confirmedEvents
        .filter(e => e.counterparty_email)
        .map(e => e.counterparty_email)
    ).size;

    return {
      user,
      events: confirmedEvents,
      stats: {
        total_confirmed: confirmedEvents.length,
        unique_clients: uniqueClients,
      }
    };
  } catch (error) {
    console.error('Error loading profile:', error);
    return null;
  }
}

export default async function ProfilePage({
  params,
}: {
  params: { slug: string };
}) {
  const profileData = await getProfileData(params.slug);

  if (!profileData) {
    notFound();
  }

  const { user, events, stats } = profileData;
  const trustLevelInfo = TRUST_LEVEL_LABELS[user.trust_level];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-5xl mx-auto px-4 py-12">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold mb-4 text-gray-900">{user.name}</h1>
            
            <div
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg mb-4 ${
                trustLevelInfo.color === 'green'
                  ? 'bg-green-50 border border-green-200'
                  : trustLevelInfo.color === 'yellow'
                  ? 'bg-yellow-50 border border-yellow-200'
                  : 'bg-gray-50 border border-gray-200'
              }`}
            >
              <span className="text-2xl">{trustLevelInfo.icon}</span>
              <div>
                <div className="font-bold text-gray-900">{trustLevelInfo.label}</div>
                <div className="text-xs text-gray-700">{trustLevelInfo.description}</div>
              </div>
            </div>

            <p className="text-gray-600 text-sm">
              На платформе с {formatDate(user.created_at)}
            </p>
          </div>

          <div className="grid grid-cols-3 gap-6 max-w-2xl mx-auto">
            <StatBox
              label="Подтверждённых работ"
              value={stats.total_confirmed}
              icon="✅"
            />
            <StatBox
              label="Уникальных клиентов"
              value={stats.unique_clients}
              icon="👥"
            />
            <StatBox
              label="Месяцев на платформе"
              value={Math.max(1, Math.floor((Date.now() - new Date(user.created_at).getTime()) / (1000 * 60 * 60 * 24 * 30)))}
              icon="📅"
            />
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-12">
        <h2 className="text-2xl font-bold mb-6 text-gray-900">
          История подтверждённых работ
        </h2>

        {events.length === 0 ? (
          <div className="bg-white rounded-lg shadow-sm p-12 text-center">
            <div className="text-5xl mb-4">📋</div>
            <p className="text-gray-600">Пока нет подтверждённых работ</p>
          </div>
        ) : (
          <div className="space-y-4">
            {events.map((event) => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        )}
      </div>

      <div className="bg-white border-t border-gray-200 py-8">
        <div className="max-w-5xl mx-auto px-4 text-center">
          <p className="text-sm text-gray-600 mb-4">
            <strong className="text-gray-900">Профиль Доверия</strong> — инфраструктура фиксации фактов выполненных работ
          </p>
          <a
            href="/"
            className="text-sm text-gray-900 hover:text-gray-700 font-medium"
          >
            Создать свой профиль →
          </a>
        </div>
      </div>
    </div>
  );
}

function StatBox({ label, value, icon }: { label: string; value: number; icon: string }) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 text-center">
      <div className="text-3xl mb-2">{icon}</div>
      <div className="text-3xl font-bold text-gray-900 mb-1">{value}</div>
      <div className="text-xs text-gray-600">{label}</div>
    </div>
  );
}

function EventCard({ event }: { event: TrustEvent }) {
  const statusInfo = EVENT_STATUS_LABELS[event.status];
  const hasEdits = event.status === 'confirmed_with_edits';

  const getCounterpartyDisplay = () => {
    if (event.counterparty_anonymous) return '[Конфиденциально]';
    if (event.counterparty_name) return event.counterparty_name;
    if (event.counterparty_email) return event.counterparty_email;
    return 'Не указан';
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h3 className="font-bold text-lg text-gray-900">{event.service_type}</h3>
            <span className="px-3 py-1 rounded-full text-xs font-medium border bg-green-50 border-green-200 text-green-800">
              {statusInfo.icon} {statusInfo.label}
            </span>
          </div>
          <p className="text-gray-700 text-sm mb-4">{event.description}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
        {(event.actual_duration || event.claimed_duration) && (
          <div>
            <span className="text-gray-600">Срок:</span>{' '}
            <span className="font-medium text-gray-900">
              {event.actual_duration || event.claimed_duration} дней
            </span>
          </div>
        )}

        {(event.actual_amount || event.claimed_amount) && (
          <div>
            <span className="text-gray-600">Сумма:</span>{' '}
            <span className="font-medium text-gray-900">
              {formatAmount(event.actual_amount || event.claimed_amount || 0, event.currency)}
            </span>
          </div>
        )}

        <div>
          <span className="text-gray-600">Заказчик:</span>{' '}
          <span className="font-medium text-gray-900">{getCounterpartyDisplay()}</span>
        </div>

        <div>
          <span className="text-gray-600">Подтверждено:</span>{' '}
          <span className="font-medium text-gray-900">
            {event.confirmed_at ? formatDate(event.confirmed_at) : formatDate(event.created_at)}
          </span>
        </div>
      </div>

      {hasEdits && (
        <div className="mt-4 pt-4 border-t border-gray-100">
          <div className="bg-blue-50 rounded-lg p-3">
            <p className="text-xs text-blue-800">
              <span className="font-medium">Примечание:</span> Заказчик внёс корректировки при подтверждении
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
