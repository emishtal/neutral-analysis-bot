import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase';
import { isExpired } from '@/lib/utils';
import { sendEventConfirmedEmail, sendEventDisputedEmail, sendConfirmationReceiptEmail } from '@/lib/email';
import type { ApiResponse } from '@/types/database';

export async function GET(
  request: NextRequest,
  { params }: { params: { token: string } }
) {
  try {
    const supabase = createAdminClient();

    const { data: link, error: linkError } = await supabase
      .from('confirmation_links')
      .select(`
        *,
        trust_events (
          *,
          users (
            id,
            name,
            email
          )
        )
      `)
      .eq('token', params.token)
      .single();

    if (linkError || !link) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Ссылка не найдена' },
        { status: 404 }
      );
    }

    if (link.used_at) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Ссылка уже использована' },
        { status: 400 }
      );
    }

    if (isExpired(link.expires_at)) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Срок действия ссылки истёк' },
        { status: 400 }
      );
    }

    return NextResponse.json<ApiResponse>({
      success: true,
      data: {
        event: link.trust_events,
        user: (link.trust_events as any).users,
      },
    });
  } catch (error) {
    console.error('Get confirmation error:', error);
    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Произошла ошибка' },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { token: string } }
) {
  try {
    const body = await request.json();
    const { action, actual_duration, actual_amount, counterparty_name, counterparty_anonymous, reason, comment } = body;

    const supabase = createAdminClient();

    const { data: link } = await supabase
      .from('confirmation_links')
      .select('*, trust_events(*, users(*))')
      .eq('token', params.token)
      .single();

    if (!link || link.used_at || isExpired(link.expires_at)) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Недействительная ссылка' },
        { status: 400 }
      );
    }

    const event = (link as any).trust_events;
    const user = event.users;

    if (action === 'confirm') {
      const hasEdits = 
        (actual_duration && actual_duration !== event.claimed_duration) ||
        (actual_amount && actual_amount !== event.claimed_amount);

      await supabase
        .from('trust_events')
        .update({
          status: hasEdits ? 'confirmed_with_edits' : 'confirmed',
          actual_duration: actual_duration || event.claimed_duration,
          actual_amount: actual_amount || event.claimed_amount,
          counterparty_name: counterparty_name || null,
          counterparty_anonymous,
          confirmed_at: new Date().toISOString(),
        })
        .eq('id', event.id);

      await supabase
        .from('confirmation_links')
        .update({ used_at: new Date().toISOString() })
        .eq('id', link.id);

      await sendEventConfirmedEmail(
        user.email,
        user.name,
        event.service_type,
        hasEdits ? 'confirmed_with_edits' : 'confirmed'
      );

      if (event.counterparty_email) {
        const receiptUrl = `${process.env.NEXT_PUBLIC_APP_URL}/receipt/${link.confirmation_receipt_token}`;
        await sendConfirmationReceiptEmail(
          event.counterparty_email,
          user.name,
          event.service_type,
          receiptUrl
        );
      }

      return NextResponse.json<ApiResponse>({
        success: true,
        message: 'Событие подтверждено',
        data: { receipt_token: link.confirmation_receipt_token }
      });

    } else if (action === 'dispute') {
      await supabase
        .from('trust_events')
        .update({ status: 'disputed' })
        .eq('id', event.id);

      await supabase
        .from('disputes')
        .insert({
          event_id: event.id,
          reason: reason || 'Не указано',
          comment: comment || null,
        });

      await supabase
        .from('confirmation_links')
        .update({ used_at: new Date().toISOString() })
        .eq('id', link.id);

      await sendEventDisputedEmail(
        user.email,
        user.name,
        event.service_type,
        reason || 'Не указано'
      );

      return NextResponse.json<ApiResponse>({
        success: true,
        message: 'Спор зафиксирован',
      });
    }

    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Неверное действие' },
      { status: 400 }
    );
  } catch (error) {
    console.error('Confirm event error:', error);
    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Произошла ошибка' },
      { status: 500 }
    );
  }
}
