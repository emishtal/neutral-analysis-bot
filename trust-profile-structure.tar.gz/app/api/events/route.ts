import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/auth';
import { createAdminClient } from '@/lib/supabase';
import { getExpirationDate, getClientIP, getUserAgent, hashIP, hashUserAgent, isValidEmail } from '@/lib/utils';
import { sendConfirmationRequestEmail } from '@/lib/email';
import type { CreateEventFormData, ApiResponse, CreateEventResponse } from '@/types/database';

const APP_URL = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';

export async function POST(request: NextRequest) {
  try {
    // Проверка аутентификации
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Необходима авторизация' },
        { status: 401 }
      );
    }

    const body: CreateEventFormData = await request.json();
    const {
      service_type,
      description,
      claimed_duration,
      claimed_amount,
      currency = 'EUR',
      counterparty_email
    } = body;

    // Валидация обязательных полей
    if (!service_type || !description) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Тип услуги и описание обязательны' },
        { status: 400 }
      );
    }

    if (description.length > 500) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Описание не должно превышать 500 символов' },
        { status: 400 }
      );
    }

    // Валидация email заказчика (опционально, но если указан - должен быть валидным)
    if (counterparty_email && !isValidEmail(counterparty_email)) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Неверный формат email заказчика' },
        { status: 400 }
      );
    }

    const supabase = createAdminClient();

    // Получаем информацию о пользователе для email
    const { data: user } = await supabase
      .from('users')
      .select('name, email')
      .eq('id', session.user.id)
      .single();

    if (!user) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Пользователь не найден' },
        { status: 404 }
      );
    }

    // Получаем IP и User Agent для защиты от накрутки
    const clientIP = getClientIP(request.headers);
    const userAgent = getUserAgent(request.headers);

    // Создаём Trust Event
    const { data: event, error: eventError } = await supabase
      .from('trust_events')
      .insert({
        creator_id: session.user.id,
        service_type,
        description,
        claimed_duration: claimed_duration || null,
        claimed_amount: claimed_amount || null,
        currency,
        counterparty_email: counterparty_email?.toLowerCase() || null,
        counterparty_anonymous: false,
        status: 'pending',
        ip_hash: hashIP(clientIP),
        user_agent_hash: hashUserAgent(userAgent),
      })
      .select()
      .single();

    if (eventError || !event) {
      console.error('Error creating event:', eventError);
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Ошибка создания события' },
        { status: 500 }
      );
    }

    // Создаём Confirmation Link
    const expiresAt = getExpirationDate(14); // 14 дней

    const { data: confirmationLink, error: linkError } = await supabase
      .from('confirmation_links')
      .insert({
        event_id: event.id,
        expires_at: expiresAt.toISOString(),
      })
      .select()
      .single();

    if (linkError || !confirmationLink) {
      console.error('Error creating confirmation link:', linkError);
      // Событие создано, но ссылка не создалась - это не критично
      // Можно попробовать пересоздать позже
    }

    // Отправляем email заказчику (если email указан)
    if (counterparty_email && confirmationLink) {
      const confirmationUrl = `${APP_URL}/confirm/${confirmationLink.token}`;
      
      const emailResult = await sendConfirmationRequestEmail(
        counterparty_email,
        user.name,
        service_type,
        description,
        confirmationUrl
      );

      if (!emailResult.success) {
        console.error('Failed to send confirmation email:', emailResult.error);
        // Email не отправился, но событие создано - логируем и продолжаем
      }
    }

    // Возвращаем успешный результат
    const response: CreateEventResponse = {
      event,
      confirmation_link: {
        url: confirmationLink 
          ? `${APP_URL}/confirm/${confirmationLink.token}`
          : '',
        token: confirmationLink?.token || '',
        expires_at: confirmationLink?.expires_at || '',
      }
    };

    return NextResponse.json<ApiResponse<CreateEventResponse>>({
      success: true,
      data: response,
      message: 'Событие создано успешно'
    });

  } catch (error) {
    console.error('Create event error:', error);
    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Произошла ошибка при создании события' },
      { status: 500 }
    );
  }
}

// GET - получение списка событий пользователя
export async function GET(request: NextRequest) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Необходима авторизация' },
        { status: 401 }
      );
    }

    const supabase = createAdminClient();

    // Получаем все события пользователя
    const { data: events, error } = await supabase
      .from('trust_events')
      .select(`
        *,
        disputes (*)
      `)
      .eq('creator_id', session.user.id)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching events:', error);
      return NextResponse.json<ApiResponse>(
        { success: false, error: 'Ошибка получения событий' },
        { status: 500 }
      );
    }

    return NextResponse.json<ApiResponse>({
      success: true,
      data: events || []
    });

  } catch (error) {
    console.error('Get events error:', error);
    return NextResponse.json<ApiResponse>(
      { success: false, error: 'Произошла ошибка при получении событий' },
      { status: 500 }
    );
  }
}
