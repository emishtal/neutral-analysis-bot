import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase';
import { hashPassword, generateProfileSlug, getExpirationDate } from '@/lib/utils';
import { sendVerificationEmail } from '@/lib/email';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password, name } = body;

    // Валидация
    if (!email || !password || !name) {
      return NextResponse.json(
        { error: 'Все поля обязательны' },
        { status: 400 }
      );
    }

    if (password.length < 8) {
      return NextResponse.json(
        { error: 'Пароль должен содержать минимум 8 символов' },
        { status: 400 }
      );
    }

    const supabase = createAdminClient();

    // Проверка существования email
    const { data: existingUser } = await supabase
      .from('users')
      .select('id')
      .eq('email', email.toLowerCase())
      .single();

    if (existingUser) {
      return NextResponse.json(
        { error: 'Email уже зарегистрирован' },
        { status: 409 }
      );
    }

    // Хеширование пароля
    const passwordHash = await hashPassword(password);

    // Генерация уникального slug
    const profileSlug = generateProfileSlug(name);

    // Создание пользователя
    const { data: newUser, error: userError } = await supabase
      .from('users')
      .insert({
        email: email.toLowerCase(),
        password_hash: passwordHash,
        name,
        profile_slug: profileSlug,
        email_verified: false,
      })
      .select()
      .single();

    if (userError) {
      console.error('Error creating user:', userError);
      return NextResponse.json(
        { error: 'Ошибка создания пользователя' },
        { status: 500 }
      );
    }

    // Создание токена верификации
    const expiresAt = getExpirationDate(7); // 7 дней на верификацию

    const { data: verificationToken, error: tokenError } = await supabase
      .from('email_verification_tokens')
      .insert({
        user_id: newUser.id,
        expires_at: expiresAt.toISOString(),
      })
      .select()
      .single();

    if (tokenError) {
      console.error('Error creating verification token:', tokenError);
      // Продолжаем, пользователь создан
    }

    // Отправка email
    if (verificationToken) {
      await sendVerificationEmail(email, name, verificationToken.token);
    }

    return NextResponse.json({
      success: true,
      message: 'Аккаунт создан. Проверьте email для подтверждения.',
    });
  } catch (error) {
    console.error('Signup error:', error);
    return NextResponse.json(
      { error: 'Произошла ошибка при регистрации' },
      { status: 500 }
    );
  }
}
