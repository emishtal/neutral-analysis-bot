import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase';
import { isExpired } from '@/lib/utils';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { token } = body;

    if (!token) {
      return NextResponse.json(
        { error: 'Токен не предоставлен' },
        { status: 400 }
      );
    }

    const supabase = createAdminClient();

    // Найти токен
    const { data: verificationToken, error: tokenError } = await supabase
      .from('email_verification_tokens')
      .select('*')
      .eq('token', token)
      .single();

    if (tokenError || !verificationToken) {
      return NextResponse.json(
        { error: 'Недействительный токен верификации' },
        { status: 400 }
      );
    }

    // Проверка использован ли токен
    if (verificationToken.used_at) {
      return NextResponse.json(
        { error: 'Токен уже использован' },
        { status: 400 }
      );
    }

    // Проверка истёк ли токен
    if (isExpired(verificationToken.expires_at)) {
      return NextResponse.json(
        { error: 'Токен истёк. Запросите новое письмо для подтверждения' },
        { status: 400 }
      );
    }

    // Обновить пользователя
    const { error: userError } = await supabase
      .from('users')
      .update({ email_verified: true })
      .eq('id', verificationToken.user_id);

    if (userError) {
      console.error('Error verifying user:', userError);
      return NextResponse.json(
        { error: 'Ошибка верификации пользователя' },
        { status: 500 }
      );
    }

    // Отметить токен как использованный
    await supabase
      .from('email_verification_tokens')
      .update({ used_at: new Date().toISOString() })
      .eq('id', verificationToken.id);

    return NextResponse.json({
      success: true,
      message: 'Email успешно подтверждён',
    });
  } catch (error) {
    console.error('Verification error:', error);
    return NextResponse.json(
      { error: 'Произошла ошибка при верификации' },
      { status: 500 }
    );
  }
}
