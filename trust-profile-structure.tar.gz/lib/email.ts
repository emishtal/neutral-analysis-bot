import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

const FROM_EMAIL = process.env.RESEND_FROM_EMAIL || 'noreply@trustprofile.com';
const APP_URL = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';

/**
 * Отправка email для подтверждения регистрации
 */
export async function sendVerificationEmail(
  to: string,
  name: string,
  token: string
) {
  const verificationUrl = `${APP_URL}/verify-email?token=${token}`;
  
  try {
    await resend.emails.send({
      from: FROM_EMAIL,
      to,
      subject: 'Подтвердите email в Trust Profile',
      html: `
        <h2>Привет, ${name}!</h2>
        <p>Спасибо за регистрацию в Trust Profile.</p>
        <p>Подтвердите свой email, перейдя по ссылке:</p>
        <p><a href="${verificationUrl}" style="display: inline-block; padding: 12px 24px; background: #000; color: #fff; text-decoration: none; border-radius: 6px;">Подтвердить email</a></p>
        <p>Или скопируйте эту ссылку в браузер:</p>
        <p>${verificationUrl}</p>
        <p><small>Если вы не регистрировались в Trust Profile, просто проигнорируйте это письмо.</small></p>
      `
    });
    return { success: true };
  } catch (error) {
    console.error('Error sending verification email:', error);
    return { success: false, error };
  }
}

/**
 * Отправка ссылки на подтверждение события заказчику
 */
export async function sendConfirmationRequestEmail(
  to: string,
  creatorName: string,
  serviceType: string,
  description: string,
  confirmationUrl: string
) {
  try {
    await resend.emails.send({
      from: FROM_EMAIL,
      to,
      subject: 'Подтвердите выполнение работы',
      html: `
        <h2>Привет!</h2>
        <p>Мы с тобой договорились о выполнении работы.</p>
        
        <div style="background: #f5f5f5; padding: 16px; border-radius: 8px; margin: 20px 0;">
          <p><strong>Услуга:</strong> ${serviceType}</p>
          <p><strong>Описание:</strong> ${description}</p>
          <p><strong>Исполнитель:</strong> ${creatorName}</p>
        </div>
        
        <p><strong>Эта ссылка — не отзыв и не оценка.</strong><br>
        Она просто фиксирует факт: была ли работа выполнена.</p>
        
        <p>Один клик. Без регистрации.</p>
        
        <p><a href="${confirmationUrl}" style="display: inline-block; padding: 12px 24px; background: #000; color: #fff; text-decoration: none; border-radius: 6px;">Подтвердить выполнение</a></p>
        
        <p>Или скопируйте эту ссылку в браузер:</p>
        <p>${confirmationUrl}</p>
        
        <p><small>Ссылка действительна 14 дней.</small></p>
        
        <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
        <p style="font-size: 12px; color: #666;">
          Это письмо от Trust Profile — инфраструктуры фиксации фактов выполненных работ.
        </p>
      `
    });
    return { success: true };
  } catch (error) {
    console.error('Error sending confirmation request email:', error);
    return { success: false, error };
  }
}

/**
 * Отправка уведомления исполнителю о подтверждении
 */
export async function sendEventConfirmedEmail(
  to: string,
  name: string,
  serviceType: string,
  status: string
) {
  const statusText = status === 'confirmed_with_edits' 
    ? 'с корректировками' 
    : '';
  
  try {
    await resend.emails.send({
      from: FROM_EMAIL,
      to,
      subject: `✅ Событие подтверждено ${statusText}`,
      html: `
        <h2>Привет, ${name}!</h2>
        <p>Твоё событие было подтверждено ${statusText}:</p>
        
        <div style="background: #f5f5f5; padding: 16px; border-radius: 8px; margin: 20px 0;">
          <p><strong>Услуга:</strong> ${serviceType}</p>
          <p><strong>Статус:</strong> ✅ Подтверждено ${statusText}</p>
        </div>
        
        <p>Факт зафиксирован и отображается в твоём профиле.</p>
        
        <p><a href="${APP_URL}/dashboard" style="display: inline-block; padding: 12px 24px; background: #000; color: #fff; text-decoration: none; border-radius: 6px;">Посмотреть профиль</a></p>
      `
    });
    return { success: true };
  } catch (error) {
    console.error('Error sending event confirmed email:', error);
    return { success: false, error };
  }
}

/**
 * Отправка уведомления исполнителю о споре
 */
export async function sendEventDisputedEmail(
  to: string,
  name: string,
  serviceType: string,
  reason: string
) {
  try {
    await resend.emails.send({
      from: FROM_EMAIL,
      to,
      subject: '⚠️ Событие оспорено',
      html: `
        <h2>Привет, ${name}!</h2>
        <p>Твоё событие было оспорено:</p>
        
        <div style="background: #fff3cd; padding: 16px; border-radius: 8px; margin: 20px 0;">
          <p><strong>Услуга:</strong> ${serviceType}</p>
          <p><strong>Причина:</strong> ${reason}</p>
        </div>
        
        <p>Факт спора зафиксирован. Trust Profile не решает споры — мы только фиксируем реальность.</p>
        
        <p><a href="${APP_URL}/dashboard" style="display: inline-block; padding: 12px 24px; background: #000; color: #fff; text-decoration: none; border-radius: 6px;">Посмотреть детали</a></p>
      `
    });
    return { success: true };
  } catch (error) {
    console.error('Error sending event disputed email:', error);
    return { success: false, error };
  }
}

/**
 * Отправка квитанции заказчику после подтверждения
 */
export async function sendConfirmationReceiptEmail(
  to: string,
  creatorName: string,
  serviceType: string,
  confirmationUrl: string
) {
  try {
    await resend.emails.send({
      from: FROM_EMAIL,
      to,
      subject: '✅ Факт зафиксирован',
      html: `
        <h2>✅ Факт зафиксирован</h2>
        
        <p>Твоё подтверждение работы с ${creatorName} сохранено.</p>
        
        <div style="background: #f5f5f5; padding: 16px; border-radius: 8px; margin: 20px 0;">
          <p><strong>Услуга:</strong> ${serviceType}</p>
          <p><strong>Исполнитель:</strong> ${creatorName}</p>
        </div>
        
        <p><strong>Сохрани эту ссылку для себя:</strong></p>
        <p><a href="${confirmationUrl}" style="color: #0066cc;">${confirmationUrl}</a></p>
        
        <p>Она подтверждает, что ты работал(а) с ${creatorName} и может использоваться в будущем как доказательство сделки.</p>
        
        <hr style="margin: 30px 0; border: none; border-top: 1px solid #eee;">
        <p style="font-size: 12px; color: #666;">
          Trust Profile — инфраструктура фиксации фактов. Мы не храним персональные данные без необходимости.
        </p>
      `
    });
    return { success: true };
  } catch (error) {
    console.error('Error sending confirmation receipt email:', error);
    return { success: false, error };
  }
}
