import crypto from 'crypto';
import { nanoid } from 'nanoid';
import bcrypt from 'bcryptjs';

/**
 * Хеширование строки для приватности (SHA-256)
 */
export function hashString(str: string): string {
  return crypto.createHash('sha256').update(str).digest('hex');
}

/**
 * Получить хеш IP адреса
 */
export function hashIP(ip: string): string {
  return hashString(ip);
}

/**
 * Получить хеш User Agent
 */
export function hashUserAgent(userAgent: string): string {
  return hashString(userAgent);
}

/**
 * Генерация уникального slug для профиля
 */
export function generateProfileSlug(name: string): string {
  const slug = name
    .toLowerCase()
    .replace(/[^a-z0-9а-яё]+/gi, '-')
    .replace(/^-+|-+$/g, '');
  
  const uniqueId = nanoid(6);
  return `${slug}-${uniqueId}`;
}

/**
 * Валидация email
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Форматирование даты для отображения
 */
export function formatDate(date: string | Date): string {
  const d = new Date(date);
  return new Intl.DateTimeFormat('ru-RU', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  }).format(d);
}

/**
 * Форматирование суммы
 */
export function formatAmount(amount: number, currency: string = 'EUR'): string {
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: currency
  }).format(amount);
}

/**
 * Вычисление даты истечения (по умолчанию +14 дней)
 */
export function getExpirationDate(days: number = 14): Date {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date;
}

/**
 * Проверка истёк ли срок
 */
export function isExpired(expiresAt: string | Date): boolean {
  return new Date(expiresAt) < new Date();
}

/**
 * Получение IP из request
 */
export function getClientIP(headers: Headers): string {
  // Vercel
  const forwardedFor = headers.get('x-forwarded-for');
  if (forwardedFor) {
    return forwardedFor.split(',')[0].trim();
  }
  
  // Другие варианты
  return headers.get('x-real-ip') || 
         headers.get('cf-connecting-ip') || 
         'unknown';
}

/**
 * Получение User Agent из request
 */
export function getUserAgent(headers: Headers): string {
  return headers.get('user-agent') || 'unknown';
}

/**
 * Хеширование пароля
 */
export async function hashPassword(password: string): Promise<string> {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
}

/**
 * Проверка пароля
 */
export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  return bcrypt.compare(password, hashedPassword);
}
