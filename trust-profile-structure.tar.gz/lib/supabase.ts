import { createClient } from '@supabase/supabase-js';

// Browser client (для использования в компонентах)
export const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

// Server client (для использования в API routes и server components)
export const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!,
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false
    }
  }
);

// Функция для создания admin клиента (алиас для консистентности)
export function createAdminClient() {
  return supabaseAdmin;
}
