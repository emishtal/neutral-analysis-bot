# ИНСТРУКЦИЯ ПО НАСТРОЙКЕ БАЗЫ ДАННЫХ

## Шаг 1: Создайте Supabase проект

1. Перейдите на https://supabase.com
2. Нажмите "Start your project"
3. Создайте новый проект (выберите регион ближайший к вам)
4. Дождитесь завершения создания проекта (~2 минуты)

## Шаг 2: Выполните SQL схему

1. В левом меню Supabase выберите "SQL Editor"
2. Нажмите "New query"
3. Скопируйте ВЕСЬ содержимое файла `supabase-schema.sql` в редактор
4. Нажмите "Run" или Ctrl+Enter
5. Дождитесь успешного выполнения (в правом нижнем углу появится "Success")

### Проверка создания таблиц:

Выполните этот запрос в SQL Editor:

```sql
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
ORDER BY table_name;
```

Должны увидеть:
- confirmation_links
- disputes
- email_verification_tokens
- service_types
- trust_events
- users

## Шаг 3: Получите API ключи

1. В левом меню выберите "Project Settings" (значок шестеренки)
2. Перейдите в "API"
3. Скопируйте:
   - **Project URL** (будет похож на https://xxxxxxxxx.supabase.co)
   - **anon public** key (длинный токен начинающийся с "eyJ...")
   - **service_role** key (внизу страницы, под предупреждением)

⚠️ **ВАЖНО:** service_role key - это секретный ключ! Никогда не делитесь им и не коммитьте в git.

## Шаг 4: Настройте переменные окружения

1. Создайте файл `.env.local` в корне проекта (если его нет)
2. Заполните его:

```env
# Database (Supabase)
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# Auth (NextAuth v5)
AUTH_SECRET=your-secret-key-here-generate-random-32-chars
NEXTAUTH_URL=http://localhost:3000

# Email (Resend)
RESEND_API_KEY=re_your_api_key_here
RESEND_FROM_EMAIL=noreply@trustprofile.com

# App
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### Генерация AUTH_SECRET:

В терминале выполните:
```bash
openssl rand -base64 32
```

Или используйте любой генератор случайных строк.

## Шаг 5: Настройка Resend (Email сервис)

1. Перейдите на https://resend.com
2. Зарегистрируйтесь (бесплатно 3000 писем/месяц)
3. Создайте API key:
   - Перейдите в "API Keys"
   - Нажмите "Create API Key"
   - ⚠️ **ВАЖНО:** Выберите права "Sending access"
   - Дайте ключу имя (например, "Trust Profile")
   - Скопируйте ключ (начинается с "re_")
4. Добавьте ключ в `.env.local` как `RESEND_API_KEY`

### Настройка домена (опционально, для production):

1. В Resend перейдите в "Domains"
2. Добавьте свой домен
3. Настройте DNS записи (SPF, DKIM)
4. После верификации измените `RESEND_FROM_EMAIL` на noreply@yourdomain.com

Для разработки можно использовать `onboarding@resend.dev` (работает без верификации).

## Шаг 6: Установка зависимостей и запуск

```bash
# Установите зависимости
npm install

# Запустите dev сервер
npm run dev
```

Откройте http://localhost:3000

## Проверка работоспособности

### Тест 1: Регистрация
1. Перейдите на /auth/signup
2. Зарегистрируйтесь с реальным email
3. Проверьте почту - должно прийти письмо с подтверждением

### Тест 2: Email verification
1. Перейдите по ссылке из письма
2. Email должен подтвердиться
3. Должна появиться возможность входа

### Тест 3: Вход в систему
1. Перейдите на /auth/signin
2. Войдите с подтвержденным email
3. Должна открыться страница /dashboard

### Тест 4: Создание события
1. На dashboard нажмите "Создать новое событие"
2. Заполните форму
3. Укажите email заказчика (свой тестовый)
4. Создайте событие
5. Проверьте почту - должна прийти ссылка для подтверждения

## Troubleshooting

### Проблема: "Failed to fetch" при регистрации

**Решение:**
1. Убедитесь что `.env.local` создан и содержит все переменные
2. Перезапустите dev сервер (Ctrl+C и npm run dev)
3. Проверьте что Supabase URL и ключи корректны

### Проблема: Email не приходят

**Решение:**
1. Проверьте что RESEND_API_KEY корректный
2. Проверьте права API ключа ("Sending access" должен быть включен)
3. Проверьте спам/промоакции в почте
4. В Resend перейдите в "Logs" и посмотрите статус отправки

### Проблема: "Email не подтверждён" при входе

**Решение:**
1. Подтвердите email по ссылке из письма
2. Проверьте в Supabase (Table Editor > users) что email_verified = true
3. Если письмо не приходит - см. "Email не приходят"

### Проблема: Ошибки в консоли браузера

**Решение:**
1. Очистите кеш браузера (Ctrl+Shift+Delete)
2. Проверьте что все зависимости установлены: `npm install`
3. Проверьте консоль терминала на ошибки сервера

## Дополнительно

### Просмотр таблиц в Supabase

1. Перейдите в "Table Editor"
2. Выберите таблицу слева
3. Просматривайте/редактируйте данные

### SQL запросы для отладки

```sql
-- Просмотр всех пользователей
SELECT id, email, name, email_verified, trust_level, created_at 
FROM users;

-- Просмотр всех событий
SELECT id, service_type, status, created_at 
FROM trust_events 
ORDER BY created_at DESC;

-- Проверка токенов верификации
SELECT user_id, token, expires_at, used_at 
FROM email_verification_tokens;
```

### Сброс базы данных (если что-то пошло не так)

⚠️ **Внимание:** Это удалит ВСЕ данные!

```sql
-- Удалить все таблицы
DROP TABLE IF EXISTS disputes CASCADE;
DROP TABLE IF EXISTS confirmation_links CASCADE;
DROP TABLE IF EXISTS trust_events CASCADE;
DROP TABLE IF EXISTS email_verification_tokens CASCADE;
DROP TABLE IF EXISTS service_types CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- Удалить функции и триггеры
DROP FUNCTION IF EXISTS update_updated_at_column CASCADE;
DROP FUNCTION IF EXISTS calculate_trust_level CASCADE;
DROP FUNCTION IF EXISTS update_user_trust_level CASCADE;
```

После этого заново выполните `supabase-schema.sql`.

## Готово! 🎉

Если все шаги выполнены успешно, у вас должна работать:
- ✅ Регистрация пользователей
- ✅ Email verification
- ✅ Вход в систему
- ✅ Dashboard
- ✅ Создание Trust Events
- ✅ Email уведомления

**Следующий шаг:** День 4 - Страница подтверждения для заказчиков

---

*Версия: День 3 завершён*  
*Последнее обновление: Декабрь 2024*
