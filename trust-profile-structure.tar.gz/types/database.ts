// Database types for Trust Profile

export type TrustLevel = 'new' | 'basic' | 'verified';

export type EventStatus = 
  | 'pending' 
  | 'confirmed' 
  | 'confirmed_with_edits' 
  | 'disputed' 
  | 'expired';

export interface User {
  id: string;
  email: string;
  password_hash: string;
  name: string;
  profile_slug: string;
  email_verified: boolean;
  phone?: string;
  phone_verified: boolean;
  trust_level: TrustLevel;
  created_at: string;
  updated_at: string;
}

export interface EmailVerificationToken {
  id: string;
  user_id: string;
  token: string;
  expires_at: string;
  used_at?: string;
  created_at: string;
}

export interface TrustEvent {
  id: string;
  creator_id: string;
  
  // Детали работы
  service_type: string;
  description: string;
  
  // Сроки
  claimed_duration?: number;
  actual_duration?: number;
  
  // Сумма
  claimed_amount?: number;
  actual_amount?: number;
  currency?: string;
  
  // Контрагент
  counterparty_email?: string;
  counterparty_name?: string;
  counterparty_anonymous: boolean;
  
  // Статус
  status: EventStatus;
  
  // Метаданные
  ip_hash?: string;
  user_agent_hash?: string;
  
  // Timestamps
  created_at: string;
  confirmed_at?: string;
  updated_at: string;
}

export interface ConfirmationLink {
  id: string;
  event_id: string;
  token: string;
  expires_at: string;
  used_at?: string;
  confirmation_receipt_token?: string;
  created_at: string;
}

export interface Dispute {
  id: string;
  event_id: string;
  reason: string;
  comment?: string;
  created_at: string;
}

export interface ServiceType {
  id: number;
  name: string;
  category?: string;
  sort_order: number;
}

// ====================================
// Frontend типы для форм и UI
// ====================================

export interface CreateEventFormData {
  service_type: string;
  description: string;
  claimed_duration?: number;
  claimed_amount?: number;
  currency?: string;
  counterparty_email: string;
}

export interface ConfirmEventFormData {
  actual_duration?: number;
  actual_amount?: number;
  counterparty_anonymous: boolean;
  counterparty_name?: string;
}

export interface DisputeFormData {
  reason: string;
  comment?: string;
}

// ====================================
// API Response типы
// ====================================

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface CreateEventResponse {
  event: TrustEvent;
  confirmation_link: {
    url: string;
    token: string;
    expires_at: string;
  };
}

export interface DashboardStats {
  total_events: number;
  confirmed_events: number;
  pending_events: number;
  disputed_events: number;
  unique_counterparties: number;
  trust_level: TrustLevel;
}

// ====================================
// Extended типы с join данными
// ====================================

export interface TrustEventWithUser extends TrustEvent {
  user: Pick<User, 'id' | 'name' | 'profile_slug' | 'trust_level'>;
}

export interface TrustEventWithDispute extends TrustEvent {
  dispute?: Dispute;
}

// ====================================
// Utility типы
// ====================================

export type EventStatusLabel = {
  [K in EventStatus]: {
    label: string;
    color: string;
    icon: string;
  };
};

export const EVENT_STATUS_LABELS: EventStatusLabel = {
  pending: {
    label: 'Ожидает подтверждения',
    color: 'yellow',
    icon: '⏳'
  },
  confirmed: {
    label: 'Подтверждено',
    color: 'green',
    icon: '✅'
  },
  confirmed_with_edits: {
    label: 'Подтверждено с корректировками',
    color: 'blue',
    icon: '✅'
  },
  disputed: {
    label: 'Оспорено',
    color: 'red',
    icon: '⚠️'
  },
  expired: {
    label: 'Истекло',
    color: 'gray',
    icon: '⌛'
  }
};

export type TrustLevelLabel = {
  [K in TrustLevel]: {
    label: string;
    color: string;
    icon: string;
    description: string;
  };
};

export const TRUST_LEVEL_LABELS: TrustLevelLabel = {
  new: {
    label: 'Новый профиль',
    color: 'gray',
    icon: '⚪',
    description: 'Только созданные события, ожидает подтверждений'
  },
  basic: {
    label: 'Базовое доверие',
    color: 'yellow',
    icon: '🟡',
    description: '1-3 подтверждённых события'
  },
  verified: {
    label: 'Проверенный',
    color: 'green',
    icon: '🟢',
    description: '5+ подтверждённых событий от 3+ разных заказчиков'
  }
};
