'use client';

import { formatDate, formatAmount } from '@/lib/utils';
import type { TrustEvent } from '@/types/database';
import { EVENT_STATUS_LABELS } from '@/types/database';

interface EventsListProps {
  events: TrustEvent[];
  isLoading?: boolean;
}

export default function EventsList({ events, isLoading }: EventsListProps) {
  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-8">
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-black"></div>
        </div>
      </div>
    );
  }

  if (events.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-8">
        <div className="text-center py-12">
          <div className="text-5xl mb-4">📝</div>
          <h3 className="text-xl font-bold mb-2">Пока нет событий</h3>
          <p className="text-gray-600 mb-6">
            Создай своё первое событие, чтобы начать фиксировать факты
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {events.map((event) => (
        <EventCard key={event.id} event={event} />
      ))}
    </div>
  );
}

function EventCard({ event }: { event: TrustEvent }) {
  const statusInfo = EVENT_STATUS_LABELS[event.status];
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
      case 'confirmed_with_edits':
        return 'bg-green-50 border-green-200 text-green-800';
      case 'pending':
        return 'bg-yellow-50 border-yellow-200 text-yellow-800';
      case 'disputed':
        return 'bg-red-50 border-red-200 text-red-800';
      case 'expired':
        return 'bg-gray-50 border-gray-200 text-gray-600';
      default:
        return 'bg-gray-50 border-gray-200 text-gray-600';
    }
  };

  // Определяем что показывать вместо заказчика
  const getCounterpartyDisplay = () => {
    if (event.counterparty_anonymous) {
      return '[Конфиденциально]';
    }
    if (event.counterparty_name) {
      return event.counterparty_name;
    }
    if (event.counterparty_email) {
      return event.counterparty_email;
    }
    return 'Не указан';
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h3 className="font-bold text-lg text-gray-900">{event.service_type}</h3>
            <span
              className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(
                event.status
              )}`}
            >
              {statusInfo.icon} {statusInfo.label}
            </span>
          </div>
          <p className="text-gray-700 text-sm">{event.description}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
        {(event.claimed_duration || event.actual_duration) && (
          <div>
            <span className="text-gray-600">Срок:</span>{' '}
            <span className="font-medium text-gray-900">
              {event.actual_duration || event.claimed_duration} дней
              {event.actual_duration && event.claimed_duration !== event.actual_duration && (
                <span className="text-gray-500 ml-1">
                  (заявлено: {event.claimed_duration})
                </span>
              )}
            </span>
          </div>
        )}

        {(event.claimed_amount || event.actual_amount) && (
          <div>
            <span className="text-gray-600">Сумма:</span>{' '}
            <span className="font-medium text-gray-900">
              {formatAmount(event.actual_amount || event.claimed_amount || 0, event.currency)}
              {event.actual_amount && event.claimed_amount !== event.actual_amount && (
                <span className="text-gray-500 ml-1">
                  (заявлено: {formatAmount(event.claimed_amount, event.currency)})
                </span>
              )}
            </span>
          </div>
        )}

        {(event.counterparty_email || event.counterparty_name) && (
          <div>
            <span className="text-gray-600">Заказчик:</span>{' '}
            <span className="font-medium text-gray-900">
              {getCounterpartyDisplay()}
            </span>
          </div>
        )}

        <div>
          <span className="text-gray-600">Создано:</span>{' '}
          <span className="font-medium text-gray-900">{formatDate(event.created_at)}</span>
        </div>

        {event.confirmed_at && (
          <div>
            <span className="text-gray-600">Подтверждено:</span>{' '}
            <span className="font-medium text-gray-900">{formatDate(event.confirmed_at)}</span>
          </div>
        )}
      </div>

      {event.status === 'pending' && (
        <div className="pt-4 border-t border-gray-100">
          <button
            className="text-sm text-blue-600 hover:text-blue-800 font-medium"
            onClick={() => {
              alert('Функция копирования ссылки будет добавлена');
            }}
          >
            Скопировать ссылку для подтверждения →
          </button>
        </div>
      )}

      {event.status === 'confirmed_with_edits' && (
        <div className="pt-4 border-t border-gray-100">
          <div className="bg-blue-50 rounded-lg p-3">
            <p className="text-xs text-blue-800">
              <span className="font-medium">Примечание:</span> Заказчик внёс корректировки при подтверждении
            </p>
          </div>
        </div>
      )}

      {event.status === 'disputed' && (
        <div className="pt-4 border-t border-gray-100">
          <div className="bg-red-50 rounded-lg p-3">
            <p className="text-xs text-red-800">
              <span className="font-medium">⚠️ Внимание:</span> Заказчик оспорил это событие
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
