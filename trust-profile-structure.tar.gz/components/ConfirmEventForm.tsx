'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { formatDate, formatAmount } from '@/lib/utils';

interface ConfirmEventFormProps {
  eventData: any;
  token: string;
}

export default function ConfirmEventForm({ eventData, token }: ConfirmEventFormProps) {
  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [actualDuration, setActualDuration] = useState(eventData.event.claimed_duration || '');
  const [actualAmount, setActualAmount] = useState(eventData.event.claimed_amount || '');
  const [counterpartyName, setCounterpartyName] = useState('');
  const [counterpartyAnonymous, setCounterpartyAnonymous] = useState(false);

  const handleConfirm = async () => {
    setIsSubmitting(true);
    setError('');

    try {
      const response = await fetch(`/api/confirm/${token}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'confirm',
          actual_duration: actualDuration ? Number(actualDuration) : null,
          actual_amount: actualAmount ? Number(actualAmount) : null,
          counterparty_name: counterpartyName.trim() || null,
          counterparty_anonymous: counterpartyAnonymous,
        }),
      });

      const result = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Ошибка подтверждения');
      }

      router.push(`/confirmed?token=${result.data.receipt_token}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Произошла ошибка');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDispute = async () => {
    if (!confirm('Вы уверены что хотите открыть спор?')) return;

    setIsSubmitting(true);
    setError('');

    try {
      const reason = prompt('Укажите причину спора:');
      if (!reason) {
        setIsSubmitting(false);
        return;
      }

      const response = await fetch(`/api/confirm/${token}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'dispute',
          reason,
        }),
      });

      const result = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Ошибка');
      }

      alert('Спор зафиксирован');
      router.push('/');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Произошла ошибка');
    } finally {
      setIsSubmitting(false);
    }
  };

  const event = eventData.event;
  const user = eventData.user;

  return (
    <div className="bg-white rounded-lg shadow-sm p-8">
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-800 text-sm">
          {error}
        </div>
      )}

      <div className="mb-8">
        <h2 className="text-xl font-bold mb-4">Детали работы</h2>
        <div className="bg-gray-50 rounded-lg p-6 space-y-3">
          <div>
            <span className="text-gray-600">Исполнитель:</span>{' '}
            <span className="font-medium text-gray-900">{user.name}</span>
          </div>
          <div>
            <span className="text-gray-600">Услуга:</span>{' '}
            <span className="font-medium text-gray-900">{event.service_type}</span>
          </div>
          <div>
            <span className="text-gray-600">Описание:</span>{' '}
            <p className="mt-1 text-gray-900">{event.description}</p>
          </div>
          {event.claimed_duration && (
            <div>
              <span className="text-gray-600">Заявленный срок:</span>{' '}
              <span className="font-medium text-gray-900">{event.claimed_duration} дней</span>
            </div>
          )}
          {event.claimed_amount && (
            <div>
              <span className="text-gray-600">Заявленная сумма:</span>{' '}
              <span className="font-medium text-gray-900">
                {formatAmount(event.claimed_amount, event.currency)}
              </span>
            </div>
          )}
          <div>
            <span className="text-gray-600">Дата создания:</span>{' '}
            <span className="font-medium text-gray-900">{formatDate(event.created_at)}</span>
          </div>
        </div>
      </div>

      <div className="mb-8 space-y-6">
        <h2 className="text-xl font-bold">Подтвердите факты</h2>

        {event.claimed_duration && (
          <div>
            <label className="block text-sm font-medium text-gray-900 mb-2">
              Фактический срок (дней)
            </label>
            <input
              type="number"
              value={actualDuration}
              onChange={(e) => setActualDuration(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg text-gray-900 placeholder-gray-400"
            />
            <p className="mt-1 text-xs text-gray-500">
              Если отличается от заявленного - укажите фактический
            </p>
          </div>
        )}

        {event.claimed_amount && (
          <div>
            <label className="block text-sm font-medium text-gray-900 mb-2">
              Фактическая сумма ({event.currency})
            </label>
            <input
              type="number"
              step="0.01"
              value={actualAmount}
              onChange={(e) => setActualAmount(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg text-gray-900 placeholder-gray-400"
            />
            <p className="mt-1 text-xs text-gray-500">
              Если отличается от заявленной - укажите фактическую
            </p>
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-900 mb-2">
            Ваше имя или название организации (опционально)
          </label>
          <input
            type="text"
            value={counterpartyName}
            onChange={(e) => setCounterpartyName(e.target.value)}
            placeholder="Иван Иванов или ООО Компания"
            disabled={counterpartyAnonymous}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg text-gray-900 placeholder-gray-400 disabled:bg-gray-100"
          />
          <p className="mt-1 text-xs text-gray-500">
            Будет показано в профиле исполнителя вместо email
          </p>
        </div>

        <div>
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={counterpartyAnonymous}
              onChange={(e) => {
                setCounterpartyAnonymous(e.target.checked);
                if (e.target.checked) {
                  setCounterpartyName('');
                }
              }}
              className="w-4 h-4"
            />
            <span className="text-sm text-gray-700">
              Оставить имя анонимным (будет показано "[Конфиденциально]")
            </span>
          </label>
        </div>
      </div>

      <div className="space-y-3">
        <button
          onClick={handleConfirm}
          disabled={isSubmitting}
          className="w-full px-6 py-4 bg-black text-white rounded-lg hover:bg-gray-800 disabled:bg-gray-400 transition-colors font-medium"
        >
          {isSubmitting ? 'Обработка...' : '✅ Да, работа выполнена'}
        </button>

        <button
          onClick={handleDispute}
          disabled={isSubmitting}
          className="w-full px-6 py-4 border-2 border-red-500 text-red-500 rounded-lg hover:bg-red-50 disabled:opacity-50 transition-colors font-medium"
        >
          ⚠️ Открыть спор
        </button>
      </div>

      <p className="mt-6 text-xs text-center text-gray-500">
        Это не влияет на оплату. Мы просто фиксируем факт выполнения работы.
      </p>
    </div>
  );
}
