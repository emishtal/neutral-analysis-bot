'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import type { CreateEventFormData, CreateEventResponse } from '@/types/database';

const SERVICE_TYPES = [
  { value: 'Дизайн лендинга', label: 'Дизайн лендинга' },
  { value: 'Дизайн многостраничного сайта', label: 'Дизайн многостраничного сайта' },
  { value: 'Дизайн мобильного приложения', label: 'Дизайн мобильного приложения' },
  { value: 'Веб-разработка (frontend)', label: 'Веб-разработка (frontend)' },
  { value: 'Веб-разработка (fullstack)', label: 'Веб-разработка (fullstack)' },
  { value: 'Интеграция с API', label: 'Интеграция с API' },
  { value: 'Доработка/фикс багов', label: 'Доработка/фикс багов' },
  { value: 'SEO оптимизация', label: 'SEO оптимизация' },
  { value: 'Консультация', label: 'Консультация' },
  { value: 'Другое', label: 'Другое' },
];

const CURRENCIES = [
  { value: 'EUR', label: '€ EUR' },
  { value: 'USD', label: '$ USD' },
  { value: 'RUB', label: '₽ RUB' },
  { value: 'GBP', label: '£ GBP' },
];

interface CreateEventFormProps {
  onSuccess?: (event: CreateEventResponse) => void;
  onCancel?: () => void;
}

export default function CreateEventForm({ onSuccess, onCancel }: CreateEventFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [copiedToClipboard, setCopiedToClipboard] = useState(false);
  const [createdEvent, setCreatedEvent] = useState<CreateEventResponse | null>(null);
  const [selectedServiceType, setSelectedServiceType] = useState('');
  const [customService, setCustomService] = useState('');

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch,
    setValue
  } = useForm<CreateEventFormData>({
    defaultValues: {
      currency: 'EUR'
    }
  });

  const description = watch('description', '');
  const serviceTypeValue = watch('service_type', '');

  const onSubmit = async (data: CreateEventFormData) => {
    setIsSubmitting(true);
    setError('');

    // Если выбрано "Другое" и указана кастомная услуга, используем её
    const finalServiceType = data.service_type === 'Другое' && customService.trim()
      ? customService.trim()
      : data.service_type;

    // Валидация для "Другое"
    if (data.service_type === 'Другое' && !customService.trim()) {
      setError('Укажите тип услуги');
      setIsSubmitting(false);
      return;
    }

    const cleanData = {
      ...data,
      service_type: finalServiceType,
      claimed_duration: data.claimed_duration ? Number(data.claimed_duration) : undefined,
      claimed_amount: data.claimed_amount ? Number(data.claimed_amount) : undefined,
    };

    try {
      const response = await fetch('/api/events', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(cleanData),
      });

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.error || 'Ошибка создания события');
      }

      setCreatedEvent(result.data);
      reset();
      setCustomService('');
      setSelectedServiceType('');
      onSuccess?.(result.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Произошла ошибка');
    } finally {
      setIsSubmitting(false);
    }
  };

  const copyToClipboard = async () => {
    if (createdEvent?.confirmation_link.url) {
      try {
        await navigator.clipboard.writeText(createdEvent.confirmation_link.url);
        setCopiedToClipboard(true);
        setTimeout(() => setCopiedToClipboard(false), 2000);
      } catch (err) {
        console.error('Failed to copy:', err);
      }
    }
  };

  if (createdEvent) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="text-center mb-6">
          <div className="text-5xl mb-4">✅</div>
          <h2 className="text-2xl font-bold mb-2 text-gray-900">Событие создано!</h2>
          <p className="text-gray-700">
            Факт зафиксирован. Отправь ссылку заказчику для подтверждения.
          </p>
        </div>

        <div className="bg-gray-50 rounded-lg p-4 mb-6">
          <p className="text-sm text-gray-900 mb-2 font-medium">
            Ссылка для подтверждения:
          </p>
          <div className="flex gap-2">
            <input
              type="text"
              value={createdEvent.confirmation_link.url}
              readOnly
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg bg-white text-sm text-gray-900"
            />
            <button
              onClick={copyToClipboard}
              className="px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors text-sm font-medium whitespace-nowrap"
            >
              {copiedToClipboard ? '✓ Скопировано' : 'Копировать'}
            </button>
          </div>
          <p className="text-xs text-gray-500 mt-2">
            Ссылка действительна 14 дней
          </p>
        </div>

        <div className="space-y-3">
          <button
            onClick={() => {
              setCreatedEvent(null);
              reset();
            }}
            className="w-full px-6 py-3 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors font-medium"
          >
            Зафиксировать ещё одну работу
          </button>
          <button
            onClick={onCancel}
            className="w-full px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors font-medium"
          >
            Вернуться к списку
          </button>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="bg-white rounded-lg shadow-sm p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold mb-2 text-gray-900">Зафиксировать выполненную работу</h2>
        <p className="text-gray-700 text-sm">
          Фиксация факта ЗАВЕРШЁННОЙ работы. Не отзыв, не оценка — только подтверждённые факты.
        </p>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-800 text-sm">
          {error}
        </div>
      )}

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-900 mb-2">
            Тип услуги <span className="text-red-500">*</span>
          </label>
          <select
            {...register('service_type', { required: 'Выберите тип услуги' })}
            onChange={(e) => {
              setSelectedServiceType(e.target.value);
              setValue('service_type', e.target.value);
              if (e.target.value !== 'Другое') {
                setCustomService('');
              }
            }}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent text-gray-900"
          >
            <option value="">Выберите услугу</option>
            {SERVICE_TYPES.map((type) => (
              <option key={type.value} value={type.value}>
                {type.label}
              </option>
            ))}
          </select>
          {errors.service_type && (
            <p className="mt-1 text-sm text-red-600">{errors.service_type.message}</p>
          )}
        </div>

        {selectedServiceType === 'Другое' && (
          <div>
            <label className="block text-sm font-medium text-gray-900 mb-2">
              Укажите тип услуги <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={customService}
              onChange={(e) => setCustomService(e.target.value)}
              placeholder="Например: Копирайтинг, SMM, Видеомонтаж..."
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent text-gray-900 placeholder-gray-400"
              maxLength={100}
            />
            <p className="mt-1 text-xs text-gray-500">
              Это поможет нам добавить новые категории услуг
            </p>
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-900 mb-2">
            Описание работы <span className="text-red-500">*</span>
          </label>
          <textarea
            {...register('description', {
              required: 'Опишите работу',
              maxLength: {
                value: 500,
                message: 'Максимум 500 символов'
              }
            })}
            rows={4}
            placeholder="Например: Дизайн главной страницы интернет-магазина с каталогом и корзиной"
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent resize-none text-gray-900 placeholder-gray-400"
          />
          <div className="flex justify-between mt-1">
            {errors.description ? (
              <p className="text-sm text-red-600">{errors.description.message}</p>
            ) : (
              <p className="text-sm text-gray-500">Кратко опишите что было сделано</p>
            )}
            <p className="text-sm text-gray-500">{description.length}/500</p>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-900 mb-2">
            Заявленный срок (опционально)
          </label>
          <div className="flex gap-2 items-center">
            <input
              type="number"
              {...register('claimed_duration', {
                min: { value: 1, message: 'Минимум 1 день' },
                max: { value: 365, message: 'Максимум 365 дней' },
                valueAsNumber: true
              })}
              placeholder="7"
              className="w-32 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent text-gray-900 placeholder-gray-400"
            />
            <span className="text-gray-700">дней</span>
          </div>
          {errors.claimed_duration && (
            <p className="mt-1 text-sm text-red-600">{errors.claimed_duration.message}</p>
          )}
          <p className="mt-1 text-xs text-gray-500">
            Заказчик сможет указать фактический срок при подтверждении
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-900 mb-2">
            Заявленная сумма (опционально)
          </label>
          <div className="flex gap-2">
            <input
              type="number"
              step="0.01"
              {...register('claimed_amount', {
                min: { value: 0, message: 'Сумма не может быть отрицательной' },
                valueAsNumber: true
              })}
              placeholder="1000"
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent text-gray-900 placeholder-gray-400"
            />
            <select
              {...register('currency')}
              className="w-32 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent text-gray-900"
            >
              {CURRENCIES.map((curr) => (
                <option key={curr.value} value={curr.value}>
                  {curr.label}
                </option>
              ))}
            </select>
          </div>
          {errors.claimed_amount && (
            <p className="mt-1 text-sm text-red-600">{errors.claimed_amount.message}</p>
          )}
          <p className="mt-1 text-xs text-gray-500">
            Заказчик сможет указать фактическую сумму при подтверждении
          </p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-900 mb-2">
            Email заказчика
          </label>
          <input
            type="email"
            {...register('counterparty_email', {
              pattern: {
                value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                message: 'Неверный формат email'
              }
            })}
            placeholder="client@example.com"
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-black focus:border-transparent text-gray-900 placeholder-gray-400"
          />
          {errors.counterparty_email && (
            <p className="mt-1 text-sm text-red-600">{errors.counterparty_email.message}</p>
          )}
          <p className="mt-1 text-xs text-gray-500">
            Мы отправим ссылку для подтверждения на этот email
          </p>
        </div>
      </div>

      <div className="flex gap-4 mt-8">
        <button
          type="submit"
          disabled={isSubmitting}
          className="flex-1 px-6 py-3 bg-black text-white rounded-lg hover:bg-gray-800 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors font-medium"
        >
          {isSubmitting ? 'Создание...' : 'Зафиксировать факт'}
        </button>
        {onCancel && (
          <button
            type="button"
            onClick={onCancel}
            disabled={isSubmitting}
            className="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 disabled:bg-gray-100 disabled:cursor-not-allowed transition-colors font-medium"
          >
            Отмена
          </button>
        )}
      </div>
    </form>
  );
}
