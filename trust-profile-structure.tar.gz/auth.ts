import NextAuth, { DefaultSession } from "next-auth";
import Credentials from "next-auth/providers/credentials";
import { createAdminClient } from "@/lib/supabase";
import { verifyPassword } from "@/lib/utils";

// Расширение типов NextAuth
declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      emailVerified: boolean;
      profileSlug: string;
    } & DefaultSession["user"];
  }

  interface User {
    id: string;
    email: string;
    name: string;
    emailVerified: boolean;
    profileSlug: string;
  }
}

export const { handlers, signIn, signOut, auth } = NextAuth({
  providers: [
    Credentials({
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" }
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          return null;
        }

        const supabase = createAdminClient();

        // Получаем пользователя из БД
        const { data: user, error } = await supabase
          .from('users')
          .select('id, email, name, password_hash, email_verified, profile_slug')
          .eq('email', (credentials.email as string).toLowerCase())
          .single();

        if (error || !user) {
          return null;
        }

        // Проверяем email verified
        if (!user.email_verified) {
          throw new Error('Email не подтверждён. Проверьте почту.');
        }

        // Проверяем пароль
        const isPasswordValid = await verifyPassword(
          credentials.password as string,
          user.password_hash
        );

        if (!isPasswordValid) {
          return null;
        }

        // Возвращаем пользователя для сессии
        return {
          id: user.id,
          email: user.email,
          name: user.name,
          emailVerified: user.email_verified,
          profileSlug: user.profile_slug
        };
      }
    })
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.emailVerified = user.emailVerified;
        token.profileSlug = user.profileSlug;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.id as string;
        session.user.emailVerified = token.emailVerified as boolean;
        session.user.profileSlug = token.profileSlug as string;
      }
      return session;
    }
  },
  pages: {
    signIn: '/auth/signin',
    error: '/auth/error',
  },
  session: {
    strategy: 'jwt',
  },
  secret: process.env.AUTH_SECRET,
});
